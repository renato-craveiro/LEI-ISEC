function [fis] = tip_problem()

%STEP 1 create the FIS system
fis = mamfis;

%STEP 2 VARIABLES
fis = addInput(fis,[0,10],'Name',"service");

         %COMPLETE

%STEP 3 MEMBERSHIP FUNCTION
fis = addMF(fis,"service", "gaussmf",[1.5 0],'Name', "weak");
	
%COMPLETE for the other variables

%STEP 4 RULES
rule1 = "service==weak | food==bad => tip=weak";
rule2 = %COMPLETE
rule3 = %COMPLETE
rules=[rule rule2 rule3];
fis = addRule(fis,rules);

%STEP 5: evaluate the FIS using evalfis
for service=0:10
  	  for food=0:10
           in=[service food];
           out = evalfis(fis, in);
            fprintf('service = %d\nfood = %d\ntip = %f\n\n',service, food, out);
         end
       end
end
