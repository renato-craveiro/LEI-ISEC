
% Carregar o datasets
startData = readtable('./Dataset3/Start.csv');

% Variáveis de entrada
entrada = startData{:, 2:end-1};
  
% Variável target
target = startData{:, end};
%target = categorical(target);

% Criar a rede neural
net = feedforwardnet(10);
net.trainParam.epochs = 100;

%TREINO
% Ajusta o treinamento e as opções de desempenho
net.divideFcn = ''; % Não divide os dados, usa todos para treinamento
%options = trainingOptions('adam', 'Plots','training-progress');

% Altere funções de treino e ativação modificando 'trainFcn' e as funções de ativação nas camadas
net.trainFcn = 'trainlm';

%net.layers{1}.transferFcn = 'logsig'; % Mudança de função de ativação
net.layers{end}.transferFcn = 'softmax'; % Usa softmax para a última camada (comum para problemas de multiclasse)

% Treina a rede
% Regista o tempo de execução usando tic e toc
tic
[net,treino] = train(net, entrada', dummyvar(target)');
tempo = toc;

% Calcule o desempenho
target_pred = net(entrada');
performance = perform(net, dummyvar(target)', target_pred);
plotconfusion(dummyvar(target)', target_pred)

% Avalia o desempenho da rede
target_PredClass = vec2ind(target_pred); % Converte as saídas da rede para índices de classe
target_TestClass = vec2ind(dummyvar(target)'); % Converte target para índices de classe para comparação

% Calcula a precisão
precisaoTotal = sum(target_PredClass == target_TestClass) / numel(target_TestClass);

% Calcula o erro
erro = perform(net, dummyvar(target)', target_pred);

fprintf('Tempo de Execução: %.2f segundos\n', tempo);
fprintf('Precisão Total: %.2f\n', precisaoTotal);
fprintf('Erro: %.2f\n', erro);

disp(['Performance: ', num2str(performance)]);
