function retStr = GUITrain(nLayers,nNeur,fctTransf,fctTrain, rTrain,rVal,rTst,dataSetTrain)


%CRIAR REDE NEURONAL e GUARDAR 
% CARREGAR DATASETS
%dataSetTrain
trainData = readtable(dataSetTrain);

% PREPARACAO DE VARIAVEIS
% Chamando a função preparaData (Associa valores numéricos a categorias)
trainDataPrepared = preparaData(trainData);


%Variaveis de entrada e saida
entrada = trainDataPrepared{:, 2:end-1};
target = trainDataPrepared{:, end};

%CRIACAO DA REDE NEURONAL
hiddenLayerSize(1:nLayers)=nNeur; % Comece com 10 neurônios 
net = feedforwardnet(hiddenLayerSize);
%options = trainingOptions('adam', 'Plots','training-progress');

% Exemplo Função de Treinamento: Gradiente Conjugado Escalonado
net.trainFcn = fctTrain; 

% Exemplo Função de ativação: log-sigmoid
net.layers{1}.transferFcn = fctTransf;
net.layers{end}.transferFcn = 'softmax'; %softmax

%Numero de épocas
net.trainParam.epochs = 5000;
net.trainParam.max_fail = 500;

%Proporções de treinamento, validação e teste
net.divideParam.trainRatio = rTrain;
net.divideParam.valRatio = rVal;
net.divideParam.testRatio = rTst;

%Treinamento e Avaliação
t = dummyvar(target)';
e = entrada';
tic
[net, tr] = train(net, e, t);
tempo = toc;
%Simular
out = sim(net, entrada');

%Grafico de Erros
plotconfusion(dummyvar(target)', out)

% Calcule o desempenho
target_pred = net(entrada');
performance = perform(net, dummyvar(target)', out);

% Avalia o desempenho da rede
target_PredClass = vec2ind(target_pred); % Converte as saídas da rede para índices de classe
target_Class = vec2ind(dummyvar(target)'); % Converte target para índices de classe para comparação

% Calcula a precisão
precisaoTotal = sum(target_PredClass == target_Class) / numel(target_Class);

% Calcula o erro
erro = perform(net, out, dummyvar(target)');

fprintf('Tempo de Execução: %.2f segundos\n', tempo);
fprintf('Precisão Total: %.2f\n', precisaoTotal);
fprintf('Erro: %.2f\n', erro);



disp(['Performance: ', num2str(performance)]);
plotperf(tr)

%Calcula e mostra a percentagem de classificacoes corretas no total dos
%exemplos (CODIGO PROF)
r=0;
for i=1:size(out,2)               % Para cada classificacao  
  [a b] = max(out(:,i));          %b guarda a linha onde encontrou valor mais alto da saida obtida
  [c d] = max(t(:,i));  %d guarda a linha onde encontrou valor mais alto da saida desejada
  if b == d                       % se estao na mesma linha, a classificacao foi correta (incrementa 1)
      r = r+1;
  end
end

accuracy = r/size(out,2)*100;
fprintf('Precisao total (no treino): %f\n', accuracy)

%GUARDAR NEURAL NETWORK
FileName = 'trainedNet';
% Compara ficheiros existentes
index = 1;
while exist(sprintf('%s%d.mat', FileName, index), 'file')
    index = index + 1;  % Incrementa o index se o ficheiro existir
end

% Save the trained network with the new filename
saveFileName = sprintf('%s%d.mat', FileName, index);
save(saveFileName, 'net');

fprintf('Network saved as %s\n', saveFileName);
retStr = sprintf('Tempo de Execução: %.2f segundos\nPrecisão Total: %.2f\nErro: %.2f\nPrecisão Total: %.2f\nNetwork saved as %s\n',...
    tempo,precisaoTotal,erro,accuracy,saveFileName);
end