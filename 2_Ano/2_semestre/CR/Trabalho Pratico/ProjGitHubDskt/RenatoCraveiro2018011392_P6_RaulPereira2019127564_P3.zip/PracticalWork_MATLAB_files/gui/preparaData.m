function dataPrepared = preparaData(data)
    % Criar mapeamentos para cada categoria
    statusMap = containers.Map({'C', 'CL', 'D'}, [0, 1, 2]);
    sexMap = containers.Map({'M', 'F'}, [0, 1]);
    drugMap = containers.Map({'Placebo', 'D-penicillamine'}, [0, 1]);
    binaryMap = containers.Map({'N', 'Y'}, [0, 1]);
    edemaMap = containers.Map({'N', 'Y', 'S'}, [0, 1, 1]); % Assumindo que 'S' é tratado como 'Y'

    % % Depois converter as categorias mapeadas para valores numéricos
    data.Status = cell2mat(values(statusMap, cellstr(data.Status)));
    data.Sex = cell2mat(values(sexMap, cellstr(data.Sex)));
    data.Drug = cell2mat(values(drugMap, cellstr(data.Drug)));
    data.Ascites = cell2mat(values(binaryMap, cellstr(data.Ascites)));
    data.Edema = cell2mat(values(edemaMap, cellstr(data.Edema)));
    
    % Remover linhas com valores ausentes na coluna 'Stage'
    %data = rmmissing(data, 'DataVariables', 'Stage');
    %dataPrepared = data;

    % Confirma os valores unicos no 'Stage' para assegurar que todas as
    % classes sao implementadas
    uniqueStages = unique(data.Stage);
    disp('Unique stages present in the data:');
    disp(uniqueStages);

    % Chamando a função retrieveCBR (Preenche valores em falta na coluna target - Stage)
    dataPrepared = retrieveCBR(data); 
end