function dataFilled = retrieveCBR(data)
    if any(ismissing(data.Stage)) || any(isstrprop(data.Stage, 'alpha'))
    % Converter 'NA' para NaN e assegurar valores numéricos
        data.Stage = str2double(replace(string(data.Stage), "NA", ""));
    else
    % Assegurar que se encontram em valores numéricos
        data.Stage = double(data.Stage);
    end

    % Converter 'NA' to NaN para a coluna 'Stage' (target)
    %data.Stage = string(data.Stage);

    % Substituir 'NA' por espaço vazio temporariamente 
    % Converter para double (espaço vazio = NaN)
    %data.Stage = str2double(replace(data.Stage, "NA", "")); 

    %Preenche os espaços vazios
    fillMissingTargets(data);
    
    % Retorne o dataset com valores preenchidos
    dataFilled = data;
end

function fillMissingTargets(data)
    for i = 1:height(data)
        if isnan(data.Stage(i))
            distances = zeros(height(data), 1);
            for j = 1:height(data)
                if i ~= j
                    distances(j) = euclideanDistance(data{i, 2:end-1}, data{j, 2:end-1});
                else
                    distances(j) = inf;
                end
            end
            [~, closestIdx] = min(distances);
            data.Stage(i) = data.Stage(closestIdx);
        end
    end
end

function distance = euclideanDistance(row1, row2)
    difference = row1 - row2;
    squareDiff = difference.^2;
    sumSquare = sum(squareDiff, 'omitnan');
    distance = sqrt(sumSquare);
end