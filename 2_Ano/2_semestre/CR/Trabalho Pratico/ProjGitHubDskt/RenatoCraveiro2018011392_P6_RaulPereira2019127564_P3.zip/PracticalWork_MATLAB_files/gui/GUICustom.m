function retStr = GUICustom(loadedNN,data)
    
    
    %USAR REDE NEURONAL GUARDADA 
    % Load the trained neural network
    load(loadedNN, 'net');
    
    
    % Prepare the data using the same function used for training
    
    TEntrada = data;

    
    
    % Use the loaded network to make predictions
   
    out = sim(net, TEntrada');
    
  
    for i=1:size(out,2)
        [a,b] = max(out(:,i));
    end
   

    retStr = sprintf("Resultado %d \n Cirrose Estágio %d", b,b);
    
end
