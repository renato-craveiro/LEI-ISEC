clear;
%CRIAR REDE NEURONAL e GUARDAR 
% CARREGAR DATASETS
trainData = readtable('./Dataset3/Train.csv');
%testData = readtable('./Dataset3/Test.csv');

% PREPARACAO DE VARIAVEIS
% Chamando a função preparaData (Associa valores numéricos a categorias)
trainDataPrepared = preparaData(trainData);
%testDataPrepared = preparaData(testData);

%Variaveis de entrada e saida
entrada = trainDataPrepared{:, 2:end-1};
target = trainDataPrepared{:, end};

%CRIACAO DA REDE NEURONAL
hiddenLayerSize = [10 10]; % Comece com 10 neurônios 
net = feedforwardnet(hiddenLayerSize);
%options = trainingOptions('adam', 'Plots','training-progress');

% Exemplo Função de Treinamento: Gradiente Conjugado Escalonado
net.trainFcn = 'trainlm'; 

% Exemplo Função de ativação: log-sigmoid
net.layers{1}.transferFcn = 'tansig';
net.layers{end}.transferFcn = 'purelin'; %softmax

%Numero de épocas
net.trainParam.epochs = 5000;
net.trainParam.max_fail = 500;

%Proporções de treinamento, validação e teste
net.divideParam.trainRatio = 0.7;
net.divideParam.valRatio = 0.15;
net.divideParam.testRatio = 0.15;

%Treinamento e Avaliação
t = dummyvar(target)';
e = entrada';
tic
[net, tr] = train(net, e, t);
tempo = toc;
%Simular
out = sim(net, entrada');

%Grafico de Erros
plotconfusion(dummyvar(target)', out)

% Calcule o desempenho
target_pred = net(entrada');
performance = perform(net, dummyvar(target)', out);

% Avalia o desempenho da rede
target_PredClass = vec2ind(target_pred); % Converte as saídas da rede para índices de classe
target_Class = vec2ind(dummyvar(target)'); % Converte target para índices de classe para comparação

% Calcula a precisão
precisaoTotal = sum(target_PredClass == target_Class) / numel(target_Class);

% Calcula o erro
erro = perform(net, out, dummyvar(target)');

fprintf('Tempo de Execução: %.2f segundos\n', tempo);
fprintf('Precisão Total: %.2f\n', precisaoTotal);
fprintf('Erro: %.2f\n', erro);

disp(['Performance: ', num2str(performance)]);
plotperf(tr)

%Calcula e mostra a percentagem de classificacoes corretas no total dos
%exemplos (CODIGO PROF)
r=0;
for i=1:size(out,2)               % Para cada classificacao  
  [a b] = max(out(:,i));          %b guarda a linha onde encontrou valor mais alto da saida obtida
  [c d] = max(t(:,i));  %d guarda a linha onde encontrou valor mais alto da saida desejada
  if b == d                       % se estao na mesma linha, a classificacao foi correta (incrementa 1)
      r = r+1;
  end
end

accuracy = r/size(out,2)*100;
fprintf('Precisao total (no treino): %f\n', accuracy)

%GUARDAR NEURAL NETWORK
FileName = 'trainedNet';
% Compara ficheiros existentes
index = 1;
while exist(sprintf('%s%d.mat', FileName, index), 'file')
    index = index + 1;  % Incrementa o index se o ficheiro existir
end

% Save the trained network with the new filename
saveFileName = sprintf('%s%d.mat', FileName, index);
save(saveFileName, 'net');

fprintf('Network saved as %s\n', saveFileName);

