%Obter o ficheiro. Assume o ficheiro Train.csv por defeito. 

[filename, filepath] = uigetfile('*.csv', 'Select the CSV file');
if isequal(filename, 0)
    disp('No file selected. Searching for "Train.csv" in current directory.');
    filename = "Train.csv";
end

%Verificar se o ficheiro existe e contém dados
try
    %Guardar a tabela na variável data
    data = readtable(filename);
catch e
    errordlg(e.message,e.identifier);
    return
end

%Usar try catch caso o .csv não contenha os dados a converter
try
    % Definir o mapeamento das colunas a corrigir com os dados numéricos
    % correspondentes
    status_map = containers.Map({'C', 'CL', 'D'}, {0, 1, 2});
    drug_map = containers.Map({'Placebo', 'D-penicillamine'}, {0, 1});
    sex_map = containers.Map({'M', 'F'}, {0, 1});
    ascites_map = containers.Map({'N', 'Y'}, {0, 1});
    edema_map = containers.Map({'N', 'Y','S'}, {0, 1,1});
    
    % Converter os dados das colunas em dados numéricos consoante os
    % mapeamentos definidos anteriormente
    data.Status = cellfun(@(x) status_map(x), data.Status);
    data.Drug = cellfun(@(x) drug_map(x), data.Drug);
    data.Sex = cellfun(@(x) sex_map(x), data.Sex);
    data.Ascites = cellfun(@(x) ascites_map(x), data.Ascites);
    data.Edema = cellfun(@(x) edema_map(x), data.Edema);

catch e
    errordlg(e.message,e.identifier);
    return
end
% Guardar os dados já convertidos num ficheiro novo
writetable(data, 'Train_corr_MLAB.csv');