%USAR REDE NEURONAL GUARDADA 
% Load the trained neural network
load('trainedNet1.mat', 'net');

% Load the datasets

testData = readtable('./Dataset3/Test.csv');

% Prepare the data using the same function used for training

TEntrada = testData{:, 2:end-1};
TTarget = testData{:, end};


% Use the loaded network to make predictions
testOutput = net(TEntrada');
out = sim(net, TEntrada');
% If target labels are available, evaluate the performance
if ~isempty(TTarget)
    testPerformance = perform(net, dummyvar(TTarget)', testOutput);
    fprintf('Test Performance: %.2f\n', testPerformance);
    plotconfusion(dummyvar(TTarget)', testOutput);
end

%Calcula e mostra a percentagem de classificacoes corretas no total 

t = dummyvar(TTarget)';
r=0;
for i=1:size(out,2)               % Para cada classificacao  
  [a b] = max(out(:,i));          %b guarda a linha onde encontrou valor mais alto da saida obtida
  [c d] = max(t(:,i));  %d guarda a linha onde encontrou valor mais alto da saida desejada
  %fprintf('Categ.: %d (Real: %d)\n',b,d);
  if b == d                       % se estao na mesma linha, a classificacao foi correta (incrementa 1)
      r = r+1;
  end
end



accuracy = r/size(out,2)*100;
fprintf('Precisao total (no treino): %f\nValores acertados %d de %d\n', accuracy,r,size(out,2))


%GUARDAR NEURAL NETWORK
FileName = 'trainedNetImproved';
% Compara ficheiros existentes
index = 1;
while exist(sprintf('%s%d.mat', FileName, index), 'file')
    index = index + 1;  % Incrementa o index se o ficheiro existir
end

% Save the trained network with the new filename
saveFileName = sprintf('%s%d.mat', FileName, index);
save(saveFileName, 'net');

fprintf('Network saved as %s\n', saveFileName);
